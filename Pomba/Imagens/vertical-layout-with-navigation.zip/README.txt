A Pen created at CodePen.io. You can find this one at http://codepen.io/ettrics/pen/ogRaRv.

 Vertical scrolling sections of content with mobile hamburger navigation. Animations easily customized.